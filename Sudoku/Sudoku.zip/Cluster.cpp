#include "Cluster.hpp"

Cluster::Cluster() {

}

Cluster::~Cluster() {

}

void Cluster::shoop(char ch) {
	cout << "Shooping " << ch << endl;
	// Call Square's turnOff();
}

void Cluster::print() {
	cout << "Cluster Print\t" << endl;
}